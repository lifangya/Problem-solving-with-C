#include<iostream>
#include<cstdlib>
using namespace std;
int digit_to_int(char c);
class Money
{
	public:
	 Money(long dollars,int cents);
	 Money(long dollars);
	 Money();
	 double get_value() const;
	 friend istream& operator>>(istream& ins, Money& amount);
	 friend ostream& operator<<(ostream& outs,const Money& amount);
	 friend Money times_two(Money amount);
	 private:
	 	long all_cents;
	
};
int main()
{
	Money amount[5];
	int i;
	cout<<"Enter 5 amounts of money."<<endl;
	for(i=0;i<5;i++)
	{
		cin>>amount[i];
	}
	for(i=0;i<5;i++)
	{
		cout<<times_two(amount[i])<<" ";
	}
}
Money::Money(long dollars,int cents)
{
	if(dollars*cents<0)
	{
		cout<<"Illegall amout of money."<<endl;
		exit(1);
	}
	all_cents=100*dollars+cents;
}
Money::Money(long dollars)
{
	all_cents=100*dollars;
}
Money::Money():all_cents(0)
{
	
}
double Money::get_value() const
{
	return all_cents*0.01;
}
 istream& operator>>(istream& ins, Money& amount)
{
	char first_char,h,digit1,digit2;
	bool negative;
	long dollars;
	int cents;
	ins>>first_char;
	if(first_char=='-')
	{
		negative=true;
		ins>>first_char;
	}
	else
	{
		negative=false;
	}
	ins>>dollars>>h>>digit1>>digit2;
	if(first_char!='$'||h!='.'||!isdigit(digit1)||!isdigit(digit2)||dollars<0)
	{
		cout<<"Illegal value of money."<<endl;
		exit(1);
   }
	cents=digit_to_int(digit1)*10+digit_to_int(digit2);
	amount.all_cents=dollars*100+cents;
	if(negative)
	amount.all_cents=-amount.all_cents;
	return ins;
}
int digit_to_int(char c)
{
	return (static_cast<int>(c)-static_cast<int>('0'));
}
ostream& operator<<(ostream& outs,const Money& amount)
{
	long positive_cents,dollars,cents;
	positive_cents=labs(amount.all_cents);
	dollars=positive_cents/100;
	cents=positive_cents%100;
	if(amount.all_cents<0)
	{
		outs<<"-$"<<dollars<<'.';
	}
	else
	{
		outs<<"$"<<dollars<<'.';
	}
	if(cents<10)
		outs<<'0';
	outs<<cents;
	return outs;
}
Money times_two(Money amount)
{
	Money temp;
	temp.all_cents=2*amount.all_cents; 
	return temp;
}
