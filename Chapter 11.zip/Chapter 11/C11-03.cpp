#include <iostream>
using namespace std;
class Percent
{
	public:
		friend bool operator ==(const Percent& first,const Percent& second);
		friend bool operator <(const Percent& first,const Percent& second);
		Percent();
		Percent(int percent_value);
		friend Percent operator+(const Percent& first,const Percent& second);
		friend Percent operator-(const Percent& first,const Percent& second);
		friend Percent operator*(const Percent& first,int factor);
		friend istream& operator >>(istream& ins,Percent& the_object);
		//Overloads the >> operator to input values of type
		//Percent.
		//Precondition: If ins is a file input stream, then ins
		//has already been connected to a file.
		friend ostream& operator <<(ostream& outs,const Percent& a_percent);
		//Overloads the << operator for output values of type
		//Percent.
		//Precondition: If outs is a file output stream, then
		//outs has already been connected to a file.
	private:
		int value;
};
int main()
{
	Percent x,y(10);
	int factor;
	cout<<"Please enter your percent."<<endl;
	cin>>x;
	cout<<"My percent is "<<y<<endl;
	if(x==y)
		cout<<"Our percents are equal.\n";
	else if(x<y)
		cout<<"Your percent is smaller than mine.\n";
	else
		cout<<"WOW, your percent is larger than mine.\n";
	cout<<"Adding our percent together produces "<<x+y<<endl;
	cout<<"After your percent minus mine, the percent is now "<<x-y<<endl;
	cout<<"Enter an integer"<<endl;
	cin>>factor;
	cout<<"Timing your percent with "<<factor<<" produces "<<x*factor;
		
}
Percent::Percent():value(0)
{
	
}
Percent::Percent(int percent_value):value(percent_value)
{
	
}
bool operator ==(const Percent& first,const Percent& second)
{
	return(first.value==second.value);
}
bool operator <(const Percent& first,const Percent& second)
{
	return(first.value<second.value);
}
Percent operator+(const Percent& first,const Percent& second)
{
	Percent temp;
	temp.value=first.value+second.value;
	return temp;
 } 
 Percent operator-(const Percent& first,const Percent& second)
{
	Percent temp;
	temp.value=first.value-second.value;
	return temp;
 } 
 Percent operator*(const Percent& first,int factor)
 {
 	Percent temp;
 	temp.value=first.value*factor;
 	return temp;
 }
 
istream& operator>>(istream& ins, Percent& the_object)
{
	char h;
	ins>>the_object.value;
	ins>>h;
	if(h!='%')
	{
		cout<<"Illegal input of a percent.\n";
		exit(1);
	}
	return ins;
}

ostream& operator<<(ostream& outs, const Percent& a_percent)
{
	outs<<a_percent.value;
	outs<<"%";
	return outs;
}
