#include<iostream>
using namespace std;
class Pairs
{
	public:
		Pairs( );
		Pairs(int first, int second);
		Pairs(int first);
		friend istream& operator >>(istream& ins, Pairs& second);
		friend ostream& operator <<(ostream& outs, const Pairs& second);
		friend Pairs operator+(const Pairs& left,const Pairs& right);
		friend Pairs operator*(const Pairs& second,int factor);
	private:
		int f;
		int s;
};
int main()
{
	Pairs pair,pair2,pair3;
	int factor;
	cout<<"Please enter a Pairs."<<endl;
	cin>>pair;
	cout<<"Your Pairs is "<<pair<<endl;
	cout<<"Please enter another Pairs"<<endl;
	cin>>pair2;
	pair3=pair+pair2;
	cout<<"Adding the two Pairs together produces "<<pair3<<endl;
	cout<<"Enter an integer.\n";
	cin>>factor;
	cout<<"Again, after timing "<<factor<<". The Pairs is now "<<pair3*factor<<endl;
	Pairs pair4,pair5(1),pair6(9,8);
	cout<<"The constructor Pair() produces a Pairs: "<<pair4<<endl;
	cout<<"The constructor Pair(1) produces a Pairs: "<<pair5<<endl;
	cout<<"The constructor Pair(9,8) produces a Pairs: "<<pair6<<endl;
}
Pairs::Pairs():f(0),s(0)
{
	
}
Pairs::Pairs(int first,int second):f(first),s(second)
{
	
}
Pairs::Pairs(int first):f(first),s(0)
{
	
}
istream& operator >>(istream& ins, Pairs& second)
{
	char h;
	ins>>h;
	if(h!='(')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	ins>>second.f;
	ins>>h;
	if(h!=',')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	ins>>second.s;
	ins>>h;
	if(h!=')')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	return ins;
}
ostream& operator <<(ostream& outs, const Pairs& second)
{
	outs<<"(";
	outs<<second.f;
	outs<<",";
	outs<<second.s;
	outs<<")";
	return outs;
}
Pairs operator+(const Pairs& left,const Pairs& right)
{
	Pairs temp;
	temp.f=left.f+right.f;
	temp.s=left.s+right.s;
	return temp;
}
Pairs operator*(const Pairs& second,int factor)
{
	Pairs temp;
	temp.f=second.f*factor;
	temp.s=second.s*factor;
	return temp;
}

