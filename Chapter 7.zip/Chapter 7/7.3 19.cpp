#include<iostream>
bool search(const int a[],int number_used,int target,int& where);
using namespace std;
int main()
{
	int a[5]={1,2,3,4,5};
	int where=0;
	cout<<search(a,5,2,where)<<endl;
	cout<<where;
	
}



bool search(const int a[],int number_used,int target,int& where)
{
	bool found=false;
	for(int i=0;i<number_used;i++)
	{
		if(a[i]==target)
		{
			where=i+1;
			found=true;
		}	
	}
	return found;
}
