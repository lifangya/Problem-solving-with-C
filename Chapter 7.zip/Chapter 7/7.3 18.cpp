#include<iostream>
using namespace std;
int main()
{
	const int maxNum=10;
	char letter_box[maxNum];
	char next;
	int index=0,listNum;
	cin>>next;
	while(next!=46&&index<maxNum)
	{
		letter_box[index]=next;
		index++;
		cin>>next;
	}
	listNum=index;
	for(int i=listNum-1;i>=0;i--)
	cout<<letter_box[i]<<" ";
}
