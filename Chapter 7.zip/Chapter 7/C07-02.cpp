//This program count the number of 2s in an array
//Created by LFY on 2017-04-14
#include<iostream>
int countNum2s(int a[],int size);
using namespace std;
int main()
{
	int size;
	char again;
	do
	{
		cout<<"Please enter the size of the array"<<endl;
		cin>>size;
		int a[size];
		cout<<"Please enter the array"<<endl;
		for(int i=0;i<size;i++)
		{
			cin>>a[i];
		}	
		cout<<countNum2s(a,size)<<endl;
		cout<<"Want to try again? Y to try again and N to exit."<<endl;
		cin>>again;
    }
    while(again!='N'&&again!='n');
}

int countNum2s(int a[],int size)
{
	int sum=0;
	for(int i=0;i<size;i++)
	{
		if(a[i]==2)
		sum++;
	}
	return sum;
	
}
