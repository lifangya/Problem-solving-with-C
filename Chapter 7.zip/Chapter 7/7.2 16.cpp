#include<iostream>
using namespace std;
int unsort(double a[],int size);
int main()
{
	double a[10]={1,2,3,4,5,6,7,8,90,10};
	cout<<unsort(a,10)<<endl;
}
int unsort(double a[],int size)
{
	for(int i=0;i<size-1;i++)
	{
		if(a[i]>a[i+1])
		return i+1;		
	 } 
	 return -1;
	 
}
