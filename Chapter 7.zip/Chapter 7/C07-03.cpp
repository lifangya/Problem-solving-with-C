//This program swap the first number and the last number in an array
//Created by LFY on 201 7-04-15
#include<iostream>
void swapFrontBack(int a[],int size);
using namespace std;
int main()
{
	int size;
	do
	{
		cout<<"Please enter the size of your array"<<endl;
		cin>>size;
	}
	while(size<=0);
	cout<<"Please enter your array"<<endl;
	int a[size];
	for(int i=0;i<size;i++)
	{
		cin>>a[i];		
	}
	swapFrontBack(a,size);
	cout<<"After swap, the array is now ";
	for(int i=0;i<size;i++)
	cout<<a[i]<<" ";
	
}

void swapFrontBack(int a[],int size)
{
	int temp;
	temp=a[0];
	a[0]=a[size-1];
	a[size-1]=temp;
}

