//This program tells whether an array starts with 2 and also ends with 2
//Created by LFY on 2017-04-14

#include<iostream>
bool firstlast2(int a[],int size);
using namespace std;
int main()
{
	int size;
	char again;
	do
	{
		cout<<"Please enter the size of the array"<<endl;
		cin>>size;
		int a[size];
		cout<<"Please enter the array"<<endl;
		for(int i=0;i<size;i++)
		{
			cin>>a[i];
		}	
		cout<<firstlast2(a,size)<<endl;
		cout<<"Want to try again? Y to try again and N to exit."<<endl;
		cin>>again;
    }
    while(again!='N'&&again!='n');
}

bool firstlast2(int a[],int size)
{
	if(a[0]==2&&a[size-1]==2)
	return true;
	else
	return false;
}
