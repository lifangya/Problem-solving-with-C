#include<iostream>
using namespace std;
int main()
{
	const int maxNum=10;
	int number_array[maxNum],listNum,next,index=0;
	cin>>next;
	while(next>=0&&index<maxNum)
	{
		number_array[index]=next;
		index++;
		cin>>next;
	}
	listNum=index;
	for(int j=0;j<listNum;j++)
	cout<<number_array[j]<<" ";
 } 
