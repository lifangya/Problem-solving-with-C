//Chapter2 Practice Exercise 2
//This program calculate the square root of a number using Babylonian algorithm
#include<iostream>
using namespace std;
int main()
{
  double n,r,guess;
  cout<<"please enter a number:\n";
  cin>>n;
  cout<<"then,please guess the square root of the number.\n";
  cin>>guess;
  for(int i=1;i<=100;i++)
  {
     r=n/guess;
     guess=(guess+r)/2;
  }
  cout<<"the square root of the number is close to "<<guess<<endl;
}
