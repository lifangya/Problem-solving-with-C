//Chapter2 Practice Exercise 3
//This program converts mph to minutes-seconds per mile
#include<iostream>
using namespace std;
int main()
{   double mph,m_s_permile,sec;
    int min;
	cout<<"please enter the mph:"<<endl;
	cin>>mph;
	min=60/mph;
	sec=(60/mph-min)*60;
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);
	cout<<mph<<" mph is equal to "<<min<<" minutes and "
	    <<sec<<" seconds per mile"<<endl;
}
