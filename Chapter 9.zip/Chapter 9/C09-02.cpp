#include<iostream>
#include<cstddef>
using namespace std;
typedef double* DoublePtr;
int main()
{
	
	DoublePtr p;
	p=new double [10];
	double sum=0;
	cout<<"Please enter 10 numbers."<<endl;
	for(int i=0;i<10;i++)
	{
		cin>>p[i];
		sum+=p[i];
	}
    cout<<"The average is "<<sum/10<<endl;
    delete [] p;
	
}
