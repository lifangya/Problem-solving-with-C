#include<iostream>
using namespace std;
void addOne(int *ptrNum);
int main()
{
	int a=0;
	int* ptr;
	ptr=&a;
	addOne(ptr);
	cout<<a;
 } 
 
 void addOne(int *ptrNum)
 {
 	*ptrNum=*ptrNum+1;
 }
