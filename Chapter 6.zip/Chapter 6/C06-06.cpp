//This program reads text from one file and writes an edited version
//of the same text to another file. The edited version is identical to the unedited
//version except that every string of two or more consecutive blanks
//is replaced by a single blank. 
//Created by Lfy on 5/12/2016
#include<fstream>
#include<cstdlib>
#include<iostream>
using namespace std;
int main()
{
	ifstream in_put;
	ofstream fout;
	char next,next2;
	in_put.open("C06-06.txt");
		if(in_put.fail())
		{
			cout<<"Input file openning failed."<<endl;
			exit(1);
		}
	fout.open("C06-06output.txt");
		if(in_put.fail())
		{
			cout<<"Output file openning failed."<<endl;
			exit(1);
		}
	
		loop:
		while(!in_put.eof())
		{
			do
			{
				in_put.get(next);
				fout<<next;
		    }
			while(next!=' ');
				in_put.get(next2);
				if(next2==' ')
				{
					goto loop;	
				}
				else
				{
					fout<<next2;
	                goto loop;
				}
		}
		in_put.close();
		fout.close();
	    cout<<"File editing finished."<<endl;
	
}
