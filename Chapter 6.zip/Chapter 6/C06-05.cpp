#include<fstream>
#include<iostream>
#include<cstdlib>
using namespace std;
int main()
{
	cout<<"Please input your advice with two Return to stop."<<endl;
	ofstream fout;
	char next_symbol,symbol2;
	fout.open("C06-05.txt",ios::app);
	if(fout.fail())
	{
		cout<<"Input file openning failed."<<endl;
		exit(1);
	}
	loop:
	do
	{
		cin.get(next_symbol);
		fout<<next_symbol;
	}
	while(next_symbol!='\n');
		cin.get(symbol2);
		fout<<symbol2;
		if(symbol2=='\n')
		{
			cout<<"Your advice has been recorded."<<endl;
			fout.close();
		}
		else
		{
			goto loop;
		}
		
	
} 
