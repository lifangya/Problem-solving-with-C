//This program computes the median of the numbers which have been sorted in a file. 
//Created by Lfy on 2/12/2016
#include<fstream>
#include<iostream>
#include<cstdlib>
using namespace std;
int main()
{
	fstream in_stream;
	in_stream.open("C06-03.txt");
	if(in_stream.fail())
	{
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	double next;
	int count1=0;
	while(!in_stream.eof())
	{
		in_stream>>next;
		count1++;
	}
	//count the numbers in the file
	in_stream.close();
	in_stream.open("C06-03.txt");
	if(in_stream.fail())
    {
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	//close the file and open it again
	if(count1%2!=0)//when the count of the numbers is odd
	{
		int count2=0;
		while(!in_stream.eof())
		{
			in_stream>>next;
			count2++;
		    if(count2==(count1+1)/2)
		    cout<<"The median is "<<next<<endl;		    
		}
   }
   if(count1%2==0)//when the count of the numbers is even
   {
   	    int count3=0;
   		while(!in_stream.eof())
		{
			double m1,m2;//define the two numbers to compute the median of a 
			             //even series
			in_stream>>next;
			count3++;
			if(count3==(count1)/2)
			m1=next;
			if(count3==(count1)/2+1)
			{
				m2=next;
				cout<<"The median is "<<(m1+m2)/2.0<<endl;
			}
		}	
   }
}
