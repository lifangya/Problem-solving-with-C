//THis program computes the average and standard deviation of the 
//numbers in a file
//Created by Lfy on 3/12/2016
#include<fstream>
#include<iostream>
#include<cstdlib>
#include<cmath>
using namespace std;
int main()
{ 
	ifstream in_stream;
	in_stream.open("C06-02.txt");
	if(in_stream.fail())
	{
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	double next,sum=0,count=0,average;
	while(!in_stream.eof())
	{
		in_stream>>next;
		sum+=next;
		count++;
	}
	average=sum/count;
	cout<<"The average of the numbers is "<<average<<endl;
	in_stream.close();
	in_stream.open("C06-02.txt");
	if(in_stream.fail())
	{
		cout<<"The file fails to open."<<endl; 
		exit(1);
	}
	double sd,variance=0;
	while(!in_stream.eof())
	{
		in_stream>>next;
		variance+=(next-average)*(next-average);	
	}
	sd=sqrt(variance/count);
	cout<<"The standard deviation is "<<sd<<endl;
	
} 
