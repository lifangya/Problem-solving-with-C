//This program search a file of numbers of type int and write the largest and 
//smallest number to the screen
//Created by Lfy on 1/12/2016
#include<fstream>
#include<iostream>
#include<cstdlib>
using namespace std;
void largest(ifstream& in_stream);
//Preconditon:the file is successfully opened 
//Postcondition:the largest number in the file is output to the screen
void smallest(ifstream& in_stream);
//Preconditon:the file is successfully opened 
//Postcondition:the smallest number in the file is output to the screen
int main()
{
	ifstream in_stream;
	in_stream.open("C06-01.txt");
	if(in_stream.fail())
	{
		cout<<"File fails to open."<<endl;
		exit(1);
	}
    largest(in_stream);
    in_stream.close();
    in_stream.open("C06-01.txt");
    if(in_stream.fail())
	{
		cout<<"File fails to open."<<endl;
		exit(1);
	}    
	smallest(in_stream);
} 

void largest(ifstream& in_stream)
{
	int next,temp;
	in_stream>>temp;
	while(!in_stream.eof())
	{
	    in_stream>>next;
	    if(temp<=next)
	    	temp=next;
    }
    cout<<"The largest number is "<<temp<<endl;
}

void smallest(ifstream& in_stream)
{
	int next,small;
	in_stream>>small;
	while(!in_stream.eof())
	{
		in_stream>>next;
		if(small>=next)
		   small=next;
	}
	cout<<"The smallest number is "<<small<<endl;
}
