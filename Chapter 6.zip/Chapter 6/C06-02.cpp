//This program search a file of numbers of type double and write the average 
//of the numbers to the screen
//Created by Lfy on 1/12/2016
#include<fstream>
#include<iostream>
#include<cstdlib>
using namespace std;
int main()
{
	ifstream in_stream;
	in_stream.open("C06-02.txt");
	if(in_stream.fail())
	{
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	double next,sum,average,count;
	sum=0;
	count=0;
	while(!in_stream.eof())
	{
	    in_stream>>next;
	    sum+=next;
	    count++;
    }
    average=sum/count;
    cout<<"The average of the numbers in the file is "<<average<<endl;	
}
