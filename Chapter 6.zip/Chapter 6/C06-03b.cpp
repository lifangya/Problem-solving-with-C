//This program computes the three quartiles of the numbers 
//which have been sorted in a file. 
//Created by Lfy on 2/12/2016
#include<fstream>
#include<iostream>
#include<cstdlib>
using namespace std;
int main()
{
	fstream in_stream;
	in_stream.open("C06-03.txt");
	if(in_stream.fail())
	{
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	double next;
	int count1=0;
	while(!in_stream.eof())
	{
		in_stream>>next;
		count1++;
	}
	//count the numbers in the file
	in_stream.close();
	in_stream.open("C06-03.txt");
	if(in_stream.fail())
    {
		cout<<"The file fails to open."<<endl;
		exit(1);
	}
	//close the file and open it again
	double q1=(count1+1)/4.0;
	double q2=(count1+1)/2.0;
	double q3=(count1+1)*0.75;
	cout<<q1<<" "<<q2<<" "<<q3<<endl;
}
