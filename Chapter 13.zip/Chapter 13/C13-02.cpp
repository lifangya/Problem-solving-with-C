#include<iostream>
#include<string>
using namespace std;
class Node
{
	public:
		Node();
		Node(string the_name,Node* the_link);
		string getName() const;
		Node *getLink() const;
		void setName(string the_name);
		void setLink(Node* the_link);
		
	private:
		string name;
		Node* link;		
};
typedef Node* NodePtr;
void output(NodePtr head);
void insert(NodePtr after_me, string the_name);
void discard(NodePtr after_me);
int main()
{
	NodePtr head,p1,p2;
	head=new Node;
	p1=new Node;
	p2=new Node;
	head->setName("Emily");
	head->setLink(p1);
	p1->setName("James");
	p1->setLink(p2);
	p2->setName("Joules");
	p2->setLink(NULL);
	output(head);
	insert(p1,"Joshua");
	output(head);
	NodePtr p3;
	p3=p1->getLink();
	discard(p3);
	output(head);
	discard(head);
	discard(head);
	NodePtr tempPtr;
	tempPtr=head;
	head=head->getLink();
	delete tempPtr;
	
	output(head);	
}
Node::Node():name("noName"),link(NULL)
{
	
}
Node::Node(string the_name,Node* the_link):name(the_name),link(the_link)
{
	
}
string Node::getName() const
{
	return(name);
}
Node* Node::getLink() const
{
	return(link);
}
void Node::setName(string the_name)
{
	name=the_name;
}
void Node::setLink(Node* the_link)
{
	link=the_link;
}
void output(NodePtr head)
{
	if(head==NULL)
	{
		cout<<"This is an empty list."<<endl;
	}
	else
	{
		NodePtr temp;
		for(temp=head;temp!=NULL;temp=temp->getLink())
		{
			cout<<temp->getName()<<" ";
	 	} 
	 	cout<<endl;
	}
}
void insert(NodePtr after_me, string the_name)
{
	NodePtr temp;
	temp=new Node;
	temp->setName(the_name);
	temp->setLink(after_me->getLink());
	after_me->setLink(temp);	
}
void discard(NodePtr after_me)
{
	NodePtr temp;
	temp=new Node;
	temp=after_me->getLink();
	after_me->setLink(temp->getLink());
	delete temp;
}
