#include <iostream>
#include <string>
using namespace std;
struct Node
{
	string name;
	Node *link;
};
typedef Node* NodePtr;
int main()
{
	NodePtr listPtr, tempPtr;
	listPtr = new Node;
	listPtr->name = "Emily";
	tempPtr = new Node;
	tempPtr->name = "James";
	listPtr->link = tempPtr;
	tempPtr->link = new Node;
	tempPtr = tempPtr->link;
	tempPtr->name = "Joules";
	tempPtr->link = NULL;
	//output all names in order
	NodePtr temp;
	for(temp=listPtr;temp!=NULL;temp=temp->link)
	{
		cout<<temp->name<<" ";
	 } 
	 cout<<endl;
	 //Inserts the name ��Joshua�� in the list after ��James�� then outputs the modified list.
	 NodePtr after_me;
	 after_me=listPtr->link;
	 temp=new Node;
	 temp->name="Joshua";
	 temp->link=after_me->link;
	 after_me->link=temp;
	 for(temp=listPtr;temp!=NULL;temp=temp->link)
	{
		cout<<temp->name<<" ";
	 } 
	 cout<<endl;
	 //Deletes the node with ��Joules�� then outputs the modified list.
	 NodePtr discard,before_discard;
	 before_discard=listPtr->link;
	 before_discard=before_discard->link;
	 discard=before_discard->link;
	 before_discard->link=discard->link;
	 delete discard;
	  for(temp=listPtr;temp!=NULL;temp=temp->link)
	{
		cout<<temp->name<<" ";
	 } 
	 cout<<endl;
	 //Deletes all nodes in the list.
	 for(int i=1;i<=3;i++)
	 {
	 	NodePtr temp;
	 	temp=listPtr;
	 	listPtr=listPtr->link;
	 	delete temp;
	}
	if(listPtr==NULL)
	{
		cout<<"All the nodes are deleted.";
	}
	else
		cout<<"Fail";	
	return 0;
}
