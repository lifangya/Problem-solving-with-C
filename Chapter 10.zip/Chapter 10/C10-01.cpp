#include<iostream>
using namespace std;
class CDAccount
{
	public:
		CDAccount(double the_balance,double the_rate,int the_term);
		CDAccount();
		void output();
		void update();
		double get_balance();
		double get_rate();
		int get_term();
	private:
		double balance;
		double rate;
		int term;		
};

int main()
{
	CDAccount account1(100.0,0.1,10);
	CDAccount account2;
	cout<<"For account1:"<<endl;
	cout<<"The initial balance is "<<account1.get_balance()<<"$."<<endl;
	account1.update();
	account1.output();
	cout<<"For account2:"<<endl;
	cout<<"The initial balance is "<<account2.get_balance()<<"$."<<endl;
	account2.update();
	account2.output();
}

CDAccount::CDAccount(double the_balance,double the_rate,int the_term):balance(the_balance),rate(the_rate),term(the_term)
{

}
CDAccount::CDAccount():balance(0),rate(0),term(0)
{
	
}
void CDAccount::update()
{
	for(int i=1;i<=term;i++)
		balance=balance*(1+rate);
}
double CDAccount::get_balance()
{
	return balance;
}
double CDAccount::get_rate()
{
	return rate;
}
int CDAccount::get_term()
{
	return term;
}
void CDAccount::output()
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);	
	cout<<"The balance at maturity is "<<balance<<"$."<<endl;
	cout<<"The interest rate is "<<100*rate<<"%."<<endl;
	cout<<"The term is "<<term<<" year(s)."<<endl;
}
