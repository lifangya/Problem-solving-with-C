#include<iostream>
#include<cmath>
using namespace std;
class CDAccount
{
	public:
		CDAccount(int dollars,int cents,double the_rate,int the_term);
		CDAccount(int dollars,double the_rate,int the_term);
		CDAccount();
		void output();
		void update();
		double get_balance();
		double get_rate();
		int get_term();
	private:
		int dollars_part;
		int cents_part;
		double rate;
		int term;
		double fraction(double percent);
		double percent(double fraction);		
};

int main()
{
	CDAccount account1(100,10,10,10);
	CDAccount account2(100,10,10);
	CDAccount account3;
	cout<<"For account1:"<<endl;
	cout<<"The initial balance is "<<account1.get_balance()<<"$."<<endl;
	account1.update();
	account1.output();
	cout<<"For account2:"<<endl;
	cout<<"The initial balance is "<<account2.get_balance()<<"$."<<endl;
	account2.update();
	account2.output();
	cout<<"For account3:"<<endl;
	cout<<"The initial balance is "<<account3.get_balance()<<"$."<<endl;
	account3.update();
	account3.output();
	
}

CDAccount::CDAccount(int dollars,int cents,double the_rate,int the_term):dollars_part(dollars),cents_part(cents),rate(fraction(the_rate)),term(the_term)
{
	if(dollars<0||cents<0||the_rate<0||the_term<0)
	{
		cout<<"Illegal values."<<endl;
		exit(1);
	}
}
CDAccount::CDAccount(int dollars,double the_rate,int the_term)
{
	if(dollars<0||the_rate<0||the_term<0)
	{
		cout<<"Illegal values."<<endl;
		exit(1);
	}
	dollars_part=dollars;
	cents_part=0;
	rate=fraction(the_rate);
	term=the_term;
	
}
CDAccount::CDAccount():dollars_part(0),cents_part(0),rate(0),term(0)
{
	
}
double CDAccount::fraction(double percent)
{
	return 0.01*percent;
}

double CDAccount::percent(double fraction)
{
	return 100*fraction;
}
void CDAccount::update()
{
	double balance=get_balance();
	for(int i=1;i<=term;i++)
		balance=balance*(1+rate);
	dollars_part=static_cast<int>(floor(balance));
	cents_part=static_cast<int>(floor((balance-dollars_part)*100));
}
double CDAccount::get_balance()
{
	return (dollars_part+0.01*cents_part);
}
double CDAccount::get_rate()
{
	return percent(rate);
}
int CDAccount::get_term()
{
	return term;
}
void CDAccount::output()
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);	
	cout<<"The balance at maturity is "<<get_balance()<<"$."<<endl;
	cout<<"The interest rate is "<<get_rate()<<"%."<<endl;
	cout<<"The term is "<<term<<" year(s)."<<endl;
}
