#include<iostream>
#include<fstream>
using namespace std;
class CounterType
{
	public:
		CounterType(int count_now);
		CounterType();
		int get_count();
		void out_put(ofstream &outs);
		void addOne();
		void minusOne();
	private:
		int count;
		void check();
};
int main()
{
	ofstream fout;
	fout.open("C10-03.txt");
	if(fout.fail())
	{
		cout<<"Input file openning failed."<<endl;
		exit(1);
	}
	cout<<"Counting... ..."<<endl;
    CounterType apple1(10);
    fout<<"The original number is "<<apple1.get_count()<<endl;
    apple1.addOne();
    fout<<"After add one, ";
    apple1.out_put(fout);
    apple1.minusOne();
    fout<<"Again, after minus one, ";
    apple1.out_put(fout);
	
}
CounterType::CounterType(int count_now):count(count_now)
{
	check();
}
CounterType::CounterType():count(0)
{
	
}
int CounterType::get_count()
{
	return count;
}
void CounterType::addOne()
{
	count=count+1;
	check();
}
void CounterType::minusOne()
{
	count=count-1;
	check();
}
void CounterType::check()
{
	if(count<0)
	{
		cout<<"Illegal value."<<endl;
		exit(1);
	}
}
void CounterType::out_put(ofstream &outs)
{
	outs<<"the number is now "<<count<<endl;
}
