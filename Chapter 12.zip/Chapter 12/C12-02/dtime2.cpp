//This is the IMPLEMENTATION of the ADT DigitalTime.
//The interface for the class DigitalTime is in the header file dtime.h.
#include<iostream>
#include<cctype>
#include<cstdlib>
#include"dtime2.h"
using namespace std;
//These FUNCTION DECLARATIONS are for use in the definition of
//the overloaded input operator >>:
void read_hour(istream& ins, int& the_hour);
void read_minute(istream& ins, int& the_minute);
int digit_to_int(char c);
bool operator ==(const DigitalTime& time1, const DigitalTime& time2)
{
	return (time1.minutes==time2.minutes);
}
//Uses iostream and cstdlib:
DigitalTime::DigitalTime(int the_hour, int the_minute)
{
	if (the_hour< 0 || the_hour> 23 || the_minute< 0 || the_minute> 59)
	{
		cout<< "Illegal argument to DigitalTime constructor.";
		exit(1);
	}
	else
	{
		minutes=60*the_hour+the_minute;
	}
}
DigitalTime::DigitalTime( ) : minutes(0)
{

}
void DigitalTime::advance(int minutes_added)
{
	minutes=minutes+minutes_added;
 }
void DigitalTime::advance(int hours_added, int minutes_added)
{
	minutes=minutes+hours_added*60+minutes_added;
}

ostream& operator <<(ostream& outs, const DigitalTime& the_object)
{
	int hour_temp,hour,minute;
	hour_temp=the_object.minutes/60;
	if(hour_temp<24)
	{
		hour=hour_temp;
	}
	else
	{
		hour=hour_temp%24;
	}
	minute=the_object.minutes%60;
	outs <<hour<< ':';
	if (minute< 10)
		outs << '0';
	outs <<minute;
	return outs;
}

istream& operator >>(istream& ins, DigitalTime& the_object)
{
	int hour,minute;
	read_hour(ins, hour);
	read_minute(ins, minute);
	the_object.minutes=60*hour+minute;
	return ins;
}

int digit_to_int(char c)
{
	return (static_cast <int>(c) - static_cast<int>('0'));
}
void read_minute(istream& ins, int& the_minute)
{
	char c1, c2;
	ins >> c1 >> c2;
	if (!(isdigit(c1) && isdigit(c2)))
	{
	cout<< "Error illegal input to read_minute\n";
	exit(1);
	}
	the_minute = (digit_to_int(c1) * 10) + digit_to_int(c2);
	if (the_minute< 0 || the_minute> 59)
	{
		cout<< "Error illegal input to read_minute\n";
		exit(1);
	 }
}
void read_hour(istream& ins,int& the_hour)
{
	char c1, c2;
	ins >> c1 >> c2;
	if ( !( isdigit(c1) && (isdigit(c2) || c2 == ':' ) ) )
	{
		cout<< "Error illegal input to read_hour\n";
	 	exit(1);
	}
	if (isdigit(c1) && c2 == ':')
	{
		the_hour = digit_to_int(c1);
	}
	else //if (isdigit(c1) && isdigit(c2))
	{
		the_hour = (digit_to_int(c1) * 10) + digit_to_int(c2);
		ins >> c2;//discard ':'
	 	if (c2 != ':')
		{
			cout<< "Error illegal input to read_hour\n";
			exit(1);
	 	}
	}
	 if (the_hour < 0 || the_hour > 23)
	{
		cout<< "Error illegal input to read_hour\n";
		exit(1);
	}
}

