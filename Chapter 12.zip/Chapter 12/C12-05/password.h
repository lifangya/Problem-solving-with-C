#ifndef PASSWORD_H
#define PASSWORD_H

#include<iostream>
#include<string>
using namespace std;
namespace Authenticate
{

	class Password
	{
		public:
			friend void inputPassword();
			friend string getPassword();
		private:
			string password;
			
		
	};
}
#endif
