#include<string>
#include<iostream>
using namespace std;
bool isValid(string password);
int main()
{
	string password;
	do
		{
			cout << "Enter your password (at least 8 characters " <<"and at least one nonletter)" << endl;
			cin >> password;
		} while (!isValid(password));
}

bool isValid(string password)
	{
		string letter("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		int index;
		bool temp=false;
		if(password.length()>=8)
		{
			for(int i=0;i<password.length();i++)
			{
				index=letter.find(password[i]);
				if(index<0||index>51)
				{
						temp=true;
						break;
				}
			}
		}
		return temp;
	}
