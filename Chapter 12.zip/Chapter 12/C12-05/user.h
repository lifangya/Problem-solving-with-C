#ifndef USER_H
#define USER_H

#include<iostream>
#include<string>
using namespace std;
namespace Authenticate
{

	class user
	{
		public:
			friend void inputUserName();
			friend string getUserName();
		private:
			string username;
			
		
	};
}
#endif
