#include<iostream>
#include<cstring>
using namespace std;
bool isValid();
class user
{
		public:
		 void inputUserName();
		 string getUserName();
		private:
			string username;
			
		
};
int main()
{
	user me;
	me.inputUserName();	
	return 0;
}


	void user::inputUserName()
	{
		do
		{
			cout << "Enter your username (8 letters only)" << endl;
			cin >> username;
		} while (!isValid());
	}
	string user::getUserName()
	{
		return username;
	}

	bool isValid()
	{
		if(strlen(username)==8)
		{
			return true;
		 } 
		 else
		 {
		 	return false;
		 }
	}

