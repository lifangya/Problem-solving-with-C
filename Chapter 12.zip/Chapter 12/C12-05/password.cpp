#include<iostream>
#include<string>
#include"Password.h"
using namespace std;
namespace
{
	bool isValid();
	string password;
}
namespace Authenticate
{
	void inputPassword()
	{
		do
		{
			cout<< "Enter your password (at least 8 characters and at least one nonletter)" << endl;
			cin >> password;
		} while (!isValid());
	}
	string getPassword()
	{
		return password;
	}
}
namespace
{
	bool isValid()
	{
		string letter("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		int index;
		bool temp=false;
		if(password.length()>=8)
		{
			for(int i=0;i<password.length();i++)
			{
				index=letter.find(password[i]);
				if(index<0||index>51)
				{
						temp=true;
						break;
				}
			}
		}
		return temp;
	}
}
