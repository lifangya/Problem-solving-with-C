#include<iostream>
#include"Password.h"
#include"user.h"
using namespace std;
int main()
{
	inputUserName();
	inputPassword();
	cout << "Your username is " << getUserName() <<" and your password is: " <<
	getPassword() << endl;
	return 0;
}
