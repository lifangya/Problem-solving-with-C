#include<iostream>
#include"pairs.h"
using namespace std;
Pairs::Pairs():f(0),s(0)
{
	
}
Pairs::Pairs(int first,int second):f(first),s(second)
{
	
}
Pairs::Pairs(int first):f(first),s(0)
{
	
}
istream& operator >>(istream& ins, Pairs& second)
{
	char h;
	ins>>h;
	if(h!='(')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	ins>>second.f;
	ins>>h;
	if(h!=',')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	ins>>second.s;
	ins>>h;
	if(h!=')')
	{
		cout<<"Illegal input of a Pairs."<<endl;
		exit(1);
	}
	return ins;
}
ostream& operator <<(ostream& outs, const Pairs& second)
{
	outs<<"(";
	outs<<second.f;
	outs<<",";
	outs<<second.s;
	outs<<")";
	return outs;
}
Pairs operator+(const Pairs& left,const Pairs& right)
{
	Pairs temp;
	temp.f=left.f+right.f;
	temp.s=left.s+right.s;
	return temp;
}
Pairs operator*(const Pairs& second,int factor)
{
	Pairs temp;
	temp.f=second.f*factor;
	temp.s=second.s*factor;
	return temp;
}
