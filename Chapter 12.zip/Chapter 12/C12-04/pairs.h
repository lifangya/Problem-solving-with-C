//interface file for Chapter12 practice program4
#ifndef PAIRS_H
#define PAIRS_H
#include<iostream>
using namespace std;
class Pairs
{
	public:
		Pairs( );
		Pairs(int first, int second);
		Pairs(int first);
		friend istream& operator >>(istream& ins, Pairs& second);
		friend ostream& operator <<(ostream& outs, const Pairs& second);
		friend Pairs operator+(const Pairs& left,const Pairs& right);
		friend Pairs operator*(const Pairs& second,int factor);
	private:
		int f;
		int s;
};
#endif
