#include<iostream>
#include"pairs.h"
using namespace std;
int main()
{
	Pairs pair,pair2,pair3;
	int factor;
	cout<<"Please enter a Pairs."<<endl;
	cin>>pair;
	cout<<"Your Pairs is "<<pair<<endl;
	cout<<"Please enter another Pairs"<<endl;
	cin>>pair2;
	pair3=pair+pair2;
	cout<<"Adding the two Pairs together produces "<<pair3<<endl;
	cout<<"Enter an integer.\n";
	cin>>factor;
	cout<<"Again, after timing "<<factor<<". The Pairs is now "<<pair3*factor<<endl;
	Pairs pair4,pair5(1),pair6(9,8);
	cout<<"The constructor Pair() produces a Pairs: "<<pair4<<endl;
	cout<<"The constructor Pair(1) produces a Pairs: "<<pair5<<endl;
	cout<<"The constructor Pair(9,8) produces a Pairs: "<<pair6<<endl;
}
