#include<iostream>
#include<cctype>
#include<cstdlib>
using namespace std;
class DigitalTime
{
	public:
		friend bool operator ==(const DigitalTime& time1, const DigitalTime& time2);
		//Returns true if time1 and time2 represent the same time;
		//otherwise, returns false.
		DigitalTime(int the_hour, int the_minute);
		//Precondition: 0 <= the_hour <= 23 and 0 <= the_minute <= 59.
		//Initializes the time value to the_hour and the_minute.
		DigitalTime( );
		//Initializes the time value to 0:00 (which is midnight).
		void advance(int minutes_added);
		//Precondition: The object has a time value.
		//Postcondition: The time has been changed to minutes_added minutes later.
 		void advance(int hours_added, int minutes_added);
		//Precondition: The object has a time value.
		//Postcondition: The time value has been advanced
		//hours_added hours plus minutes_added minutes.
 		friend istream& operator >>(istream& ins, DigitalTime& the_object);
 		//Overloads the >> operator for input values of type DigitalTime.
 		//Precondition: If ins is a file input stream, then ins has already been
 		//connected to a file.
 		friend ostream& operator <<(ostream& outs, const DigitalTime& the_object);
		//Overloads the << operator for output values of type DigitalTime.
 		//Precondition: If outs is a file output stream, then outs has already been
 		//connected to a file.
 		void interval_since(const DigitalTime& a_previous_time,int& hours_in_interval, int& minutes_in_interval) const;
 		//This function computes the time interval between two values of type DigitalTime. 
		 //One of the values of type DigitalTime is the object that calls the member function interval_since
		 //and the other value of type DigitalTime is given as the first argument
 	private:
 		int hour;
 		int minute;
 	};
 	int main( )
{
	DigitalTime clock, old_clock;
	cout<< "Enter the time in 24-hour notation: ";
	cin>> clock;
	old_clock = clock;
	clock.advance(15);
	if (clock == old_clock)
		cout << "Something is wrong.";
	cout << "You entered " << old_clock << endl;
	cout << "15 minutes later the time will be "<< clock << endl;
	clock.advance(2, 15);
	cout << "2 hours and 15 minutes after that\n"<< "the time will be "<< clock << endl;
	
	DigitalTime current(1, 40), previous(2, 50);
	int hours, minutes;
	current.interval_since(previous, hours, minutes);
	cout << "The time interval between " << previous<< " and " << current << endl
		<< "is " << hours << " hours and "
		<< minutes << " minutes.\n";
	return 0;
}
void read_hour(istream& ins, int& the_hour);
void read_minute(istream& ins, int& the_minute);
int digit_to_int(char c);
bool operator ==(const DigitalTime& time1, const DigitalTime& time2)
{
	return (time1.hour == time2.hour && time1.minute == time2.minute);
}
//Uses iostream and cstdlib:
DigitalTime::DigitalTime(int the_hour, int the_minute)
{
	if (the_hour< 0 || the_hour> 23 || the_minute< 0 || the_minute> 59)
	{
		cout<< "Illegal argument to DigitalTime constructor.";
		exit(1);
	}
	else
	{
		hour = the_hour;
		minute = the_minute;
	}
}
DigitalTime::DigitalTime( ) : hour(0), minute(0)
{

}
void DigitalTime::advance(int minutes_added)
{
	int gross_minutes = minute + minutes_added;
	minute = gross_minutes % 60;
	int hour_adjustment = gross_minutes / 60;
	hour = (hour + hour_adjustment) % 24;
 }
void DigitalTime::advance(int hours_added, int minutes_added)
{
	hour = (hour + hours_added) % 24;
	advance(minutes_added);
}

ostream& operator <<(ostream& outs, const DigitalTime& the_object)
{
	outs << the_object.hour<< ':';
	if (the_object.minute< 10)
		outs << '0';
	outs << the_object.minute;
	return outs;
}

istream& operator >>(istream& ins, DigitalTime& the_object)
{
	read_hour(ins, the_object.hour);
	read_minute(ins, the_object.minute);
	return ins;
}

int digit_to_int(char c)
{
	return (static_cast <int>(c) - static_cast<int>('0'));
}
void read_minute(istream& ins, int& the_minute)
{
	char c1, c2;
	ins >> c1 >> c2;
	if (!(isdigit(c1) && isdigit(c2)))
	{
	cout<< "Error illegal input to read_minute\n";
	exit(1);
	}
	the_minute = (digit_to_int(c1) * 10) + digit_to_int(c2);
	if (the_minute< 0 || the_minute> 59)
	{
		cout<< "Error illegal input to read_minute\n";
		exit(1);
	 }
}
void read_hour(istream& ins, int& the_hour)
{
	char c1, c2;
	ins >> c1 >> c2;
	if ( !( isdigit(c1) && (isdigit(c2) || c2 == ':' ) ) )
	{
		cout<< "Error illegal input to read_hour\n";
	 	exit(1);
	}
	if (isdigit(c1) && c2 == ':')
	{
		the_hour = digit_to_int(c1);
	}
	else //if (isdigit(c1) && isdigit(c2))
	{
		the_hour = (digit_to_int(c1) * 10) + digit_to_int(c2);
		ins >> c2;//discard ':'
	 	if (c2 != ':')
		{
			cout<< "Error illegal input to read_hour\n";
			exit(1);
	 	}
	}
	 if (the_hour < 0 || the_hour > 23)
	{
		cout<< "Error illegal input to read_hour\n";
		exit(1);
	}
}
void DigitalTime::interval_since(const DigitalTime& a_previous_time,int& hours_in_interval, int& minutes_in_interval) const
{
	int minutes_converse,previous_minutes_converse,minutes_diff;
	minutes_converse=60*hour+minute;
	previous_minutes_converse=a_previous_time.hour*60+a_previous_time.minute;
	
	if(a_previous_time.hour<hour||(a_previous_time.hour==hour&&a_previous_time.minute<=minute))
	{		
		minutes_diff=minutes_converse-previous_minutes_converse;
	}
	else
	{
		minutes_diff=24*60+minutes_converse-previous_minutes_converse;	
	}
	hours_in_interval=minutes_diff/60;
	minutes_in_interval=minutes_diff%60;
}
