//Implementation file for Chapter12 practice program
#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cctype>
#include<cmath>
#include"money.h"
using namespace std;
int digit_to_int(char c);
Money operator+(const Money& amount1, const Money& amount2)
 {
 	Money temp;
 	temp.all_cents=amount1.all_cents+amount2.all_cents;
 	return temp;
 }
 Money operator-(const Money& amount1, const Money& amount2)
 {
 	Money temp;
 	temp.all_cents=amount1.all_cents-amount2.all_cents;
 	return temp;
 }
 Money operator-(const Money& amount)
 {
 	Money temp;
 	temp.all_cents=-amount.all_cents;
 	return temp;
 }
bool operator==(const Money& amount1, const Money& amount2)
 {
 	return(amount1.all_cents==amount2.all_cents);
 }
bool operator<(const Money& amount1,const Money& amount2)
 {
 	return(amount1.all_cents<amount2.all_cents);
 }
bool operator>(const Money& amount1,const Money& amount2)
 {
 	return(amount1.all_cents>amount2.all_cents);
 }
bool operator>=(const Money& amount1,const Money& amount2)
 {
 	return(amount1.all_cents>amount2.all_cents||amount1.all_cents==amount2.all_cents);
 }
bool operator<=(const Money& amount1,const Money& amount2)
 {
 	return(amount1.all_cents<amount2.all_cents||amount1.all_cents==amount2.all_cents);
 }
Money::Money(long dollars, int cents)
{
	if(dollars*cents==0)
	{
		cout<<"Illegale amount of money input.";
		exit(1);
	}
	all_cents=100*dollars+cents;
}
Money::Money(long dollars):all_cents(100*dollars)
{

}
Money::Money( )
{
	all_cents=0;
}
double Money::get_value( ) const
{
	return (all_cents*0.01);
}
istream& operator >>(istream& ins, Money& amount)
{
	char one_char,decimal,digit1,digit2;
	long dollars;
	int cents;
	bool negative;
	ins>>one_char;
	if(one_char=='-')
	{
		negative=true;
		ins>>one_char;
	}
	else
		negative=false;
	ins>>dollars>>decimal>>digit1>>digit2;
	if(one_char!='$'||decimal!='.'||!isdigit(digit1)||!isdigit(digit2)||dollars<0)
	{
		cout<<"Illegal amount of money input";
		exit(1);
	}
	cents=digit_to_int(digit1)*10+digit_to_int(digit2);
	amount.all_cents=100*dollars+cents;
	if(negative)
		amount.all_cents=-amount.all_cents;
	return ins;
}
ostream& operator<<(ostream& outs,const Money& amount)
{
	long positive_cents;
	long dollars,cents;
	positive_cents=labs(amount.all_cents);
	dollars=positive_cents/100;
	cents=positive_cents%100;
	if(amount.all_cents>0)
	{
		outs<<'$'<<dollars<<'.';
	}
	else
		outs<<"-$"<<dollars<<'.';
	if(cents<10)
		outs<<'0';
	outs<<cents;
	return outs;	
}
Money Money::percent(int percent_figure) const
{
	Money temp;
	temp.all_cents=floor(percent_figure*0.01*all_cents);
	return temp;
}
int digit_to_int(char c)
{
	return (static_cast<int>(c)-static_cast<int>('0')); 
}
