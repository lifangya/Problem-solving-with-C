//interface file for Chapter12 practice program 3
#ifndef MONEY_H
#define MONEY_H
#include<iostream>
using namespace std;
class Money
{
	public:
		friend Money operator+(const Money& amount1, const Money& amount2);
 		friend Money operator-(const Money& amount1, const Money& amount2);
		friend Money operator-(const Money& amount);
		friend bool operator==(const Money& amount1, const Money& amount2);
		friend bool operator<(const Money& amount1,const Money& amount2);
		friend bool operator>(const Money& amount1,const Money& amount2);
		friend bool operator<=(const Money& amount1,const Money& amount2);
		friend bool operator>=(const Money& amount1,const Money& amount2);
		Money(long dollars, int cents);
		Money(long dollars);
		Money( );
		double get_value( ) const;
		friend istream& operator >>(istream& ins, Money& amount);
		//Overloads the >> operator so it can be used to input values of type Money.
		//Notation for inputting negative amounts is as in .$100.00.
		//Precondition: If ins is a file input stream, then ins has already been
		//connected to a file.
		friend ostream& operator <<(ostream& outs, const Money& amount);
		//Overloads the << operator so it can be used to output values of type Money.
		//Precedes each output value of type Money with a dollar sign.
		//Precondition: If outs is a file output stream,
		//then outs has already been connected to a file.
		Money percent(int percent_figure) const;
		//Returns a percentage of the money amount in the
		//calling object. For example, if percent_figure is 10,
		//then the value returned is 10% of the amount of
		//money represented by the calling object.
		private:
			long all_cents;	
};
#endif
