// This program computes the average and standard deviation of 4 scores.
//Created by LFY on 29/11/2016
#include<iostream>
using namespace std;
double average(double s1,double s2,double s3,double s4);
//Precondition: the 4 scores entered are non-negative
//Postcondition: the function returns the average of the 4 scores
double standard_dev(double s1,double s2,double s3,double s4);
//Precondition: 4 non-negative numbers are correctly entered
//Postcondition: the function returns the standard deviation 
int main()
{
	double s1,s2,s3,s4,ave,sd;
	char done;
	do
	{
	   cout<<"Please enter 4 scores."<<endl;
	   cin>>s1>>s2>>s3>>s4;
	   ave=average(s1,s2,s3,s4);
	   sd=standard_dev(s1,s2,s3,s4);
	   cout.setf(ios::fixed);
	   cout.setf(ios::showpoint);
	   cout.precision(2);
	   cout<<"The average is "<<ave<<endl;
	   cout<<"The standard deviation is "<<sd<<endl;
	   cout<<"Try again? Y for yes, N for No."<<endl;
	   cin>> done;
    }
	while(done=='y'||done=='Y');
}

double average(double s1,double s2,double s3,double s4)
{
	return((s1+s2+s3+s4)/4.0);
}

#include<math.h>
double standard_dev(double s1,double s2,double s3,double s4)
{
	double sd,ave;
	ave=average(s1,s2,s3,s4);
	sd=sqrt((s1-ave)*(s1-ave)+(s2-ave)*(s2-ave)+(s3-ave)*(s3-ave)+(s4-ave)*(s4-ave));
	return sd;	
}
