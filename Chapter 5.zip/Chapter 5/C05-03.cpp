//This program converts a length in meters and centimeters to length in feet and 
//inches
//Created by Lfy on 30/11/2016
#include<iostream>
using namespace std;
const double cm2f=1.0/30.48;
const double cm2i=12.0/30.48;
void get_length(int& meter,double& cm);
//This function gets input of a length in meters and centimeters
//It returns nothing
int feet_convert(int meter,double cm);
//precondition:meters and centimeters are input correctly
//postcondition:the function returns the corresponding feet 
double inch_convert(int meter,double cm);
//precondition:meters and centimeters are input correctly
//postcondition:the function returns the corresponding inches 
void output(int feet,double inch);
//This function outputs results
int main()
{
	int feet,meter;
	double inch,cm;
	char done;
	do
	{
		get_length(meter,cm);
		feet=feet_convert(meter,cm);
		inch=inch_convert(meter,cm);
		output(feet,inch);
		cout<<"Try again? Y for Yes and N for No."<<endl;
		cin>>done;
	}
	while(done=='y'||done=='Y');
	
}

void get_length(int& meter,double& cm)
{
	cout<<"Please enter the length in meters and centimeters. tip:" 
     	<<"the number for centimeter should be smaller than 100."<<endl;
	cin>>meter>>cm;
}
#include<math.h>
int feet_convert(int meter,double cm)
{
	int feet;
	feet=floor((100*meter+cm)*cm2f);
	return feet;
}

double inch_convert(int meter,double cm)
{
	double inch;
	inch=(100*meter+cm)*cm2i-feet_convert(meter,cm)*12;
	return inch;
}
void output(int feet,double inch)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout<<"The length is "<<feet<<" feet and "<<inch<<" inches."
	    <<endl;
}
