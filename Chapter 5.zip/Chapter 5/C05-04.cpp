//This program converts a length in feet and inches to length in meters and 
//centimeters or converts a length in meters and centimeters to feet and inches
//Created by Lfy on 30/11/2016
#include<iostream>
using namespace std;
const double f2m=0.3048;
const double i2cm=1/12.0*30.48;
const double cm2f=1.0/30.48;
const double cm2i=12.0/30.48;
void get_length1(int& feet,double& inch);
//This function gets input of a length in feet and inches
//It returns nothing
void get_length2(int& meter,double& cm);
int meter_convert(int feet);
//precondition:feet and inches are input correctly
//postcondition:the function returns the corresponding meters 
int feet_convert(int meter,double cm);
double cm_convert(int feet,double inch);
//precondition:feet and inches are input correctly
//postcondition:the function returns the corresponding centimeters 
double inch_convert(int meter,double cm);
void output1(int meter,double cm);
//This function outputs results
void output2(int feet,double inch);
int main()
{
	int feet,meter,type;
	double inch,cm;
	char done;
	do
	{
		cout<<"Type 1 to convert a length in feet and inches to meters and centimeters.\n"
		    << "Type 2 to convert a length in meters and centimeters to feet and inches."
		    <<endl; 
		cin>>type;
		
		if(type==1)
		{
		
	    	get_length1(feet,inch);
			meter=meter_convert(feet);
			cm=cm_convert(feet,inch);
			output1(meter,cm);
	    }
	    else if(type==2)
	    {
	    	get_length2(meter,cm);
	    	feet=feet_convert(meter,cm);
	    	inch=inch_convert(meter,cm);
	    	output2(feet,inch);
	    	
	    }
			cout<<"Try again? Y for Yes and N for No."<<endl;
			cin>>done;
	}
	while(done=='y'||done=='Y');
	
}

void get_length1(int& feet,double& inch)
{
	cout<<"Please enter the length in feet and inches. tip:" 
     	<<"the number for inch should be smaller than 12."<<endl;
	cin>>feet>>inch;
}
int meter_convert(int feet)
{
	int meter;
	meter=feet*f2m;
	return meter;
}

double cm_convert(int feet,double inch)
{
	double cm;
	cm=(static_cast<double>(feet*f2m)-meter_convert(feet))*100+inch*i2cm;
	return cm;
}
void output1(int meter,double cm)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout<<"The length is "<<meter<<" meter(s) and "<<cm<<" centimeter(s)."
	    <<endl;
}
void get_length2(int& meter,double& cm)
{
	cout<<"Please enter the length in meters and centimeters. tip:" 
     	<<"the number for centimeter should be smaller than 100."<<endl;
	cin>>meter>>cm;
}
#include<math.h>
int feet_convert(int meter,double cm)
{
	int feet;
	feet=floor((100*meter+cm)*cm2f);
	return feet;
}

double inch_convert(int meter,double cm)
{
	double inch;
	inch=(100*meter+cm)*cm2i-feet_convert(meter,cm)*12;
	return inch;
}
void output2(int feet,double inch)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout<<"The length is "<<feet<<" feet and "<<inch<<" inches."
	    <<endl;
}

