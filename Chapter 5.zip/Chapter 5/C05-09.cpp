#include<cassert>
void triangle_area(double a,double b,double c)
{
        double &s,&area;
		assert(a+b>c&&a+c>b&&b+c>a);
		s=(a+b+c)/2.0;
		area=sqrt(s*(s-a)*(s-b)*(s-c));
		return 0;
}
        
        
