//This program converts a length in feet and inches to length in meters and 
//centimeters
//Created by Lfy on 29/11/2016
#include<iostream>
using namespace std;
const double f2m=0.3048;
const double i2cm=1/12.0*30.48;
void get_length(int& feet,double& inch);
//This function gets input of a length in feet and inches
//It returns nothing
int meter_convert(int feet);
//precondition:feet and inches are input correctly
//postcondition:the function returns the corresponding meters 
double cm_convert(int feet,double inch);
//precondition:feet and inches are input correctly
//postcondition:the function returns the corresponding centimeters 
void output(int meter,double centimeter);
//This function outputs results
int main()
{
	int feet,meter;
	double inch,centimeter;
	char done;
	do
	{
		get_length(feet,inch);
		meter=meter_convert(feet);
		centimeter=cm_convert(feet,inch);
		output(meter,centimeter);
		cout<<"Try again? Y for Yes and N for No."<<endl;
		cin>>done;
	}
	while(done=='y'||done=='Y');
	
}

void get_length(int& feet,double& inch)
{
	cout<<"Please enter the length in feet and inches. tip:" 
     	<<"the number for inch should be smaller than 12."<<endl;
	cin>>feet>>inch;
}
int meter_convert(int feet)
{
	int meter;
	meter=feet*f2m;
	return meter;
}

double cm_convert(int feet,double inch)
{
	double cm;
	cm=(static_cast<double>(feet*f2m)-meter_convert(feet))*100+inch*i2cm;
	return cm;
}
void output(int meter,double centimeter)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout<<"The length is "<<meter<<" meter(s) and "<<centimeter<<" centimeter(s)."
	    <<endl;
}

