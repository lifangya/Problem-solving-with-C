//This program converts a weight in pounds and ounces to weight in kilograms and 
//grams
//Created by Lfy on 30/11/2016
#include<iostream>
using namespace std;
const double p2kg=1.0/2.2046;
const double o2gram=1000.0/(16.0*2.2046);
void get_weight(int& pound,double& ounce);
//This function gets input of a weight in pounds and ounces
//It returns nothing
int kg_convert(int pound);
//precondition:pounds and ounces are input correctly
//postcondition:the function returns the corresponding kilograms 
double gram_convert(int pound,double ounce);
//precondition:pounds and ounces are input correctly
//postcondition:the function returns the corresponding grams 
void output(int kg,double gram);
//This function outputs results
int main()
{
	int pound,kg;
	double ounce,gram;
	char done;
	do
	{
		get_weight(pound,ounce);
		kg=kg_convert(pound);
		gram=gram_convert(pound,ounce);
		output(kg,gram);
		cout<<"Try again? Y for Yes and N for No."<<endl;
		cin>>done;
	}
	while(done=='y'||done=='Y');
	
}

void get_weight(int& pound,double& ounce)
{
	cout<<"Please enter the weight in pounds and ounces. tip:" 
     	<<"the number for ounce should be smaller than 16."<<endl;
	cin>>pound>>ounce;
}
int kg_convert(int pound)
{
	int kg;
	kg=pound*p2kg;
	return kg;
}

double gram_convert(int pound,double ounce)
{
	double gram;
	gram=(static_cast<double>(pound*p2kg)-kg_convert(pound))*1000+ounce*o2gram;
	return gram;
}
void output(int kg,double gram)
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout<<"The weight is "<<kg<<" kilogram(s) and "<<gram<<" gram(s)."
	    <<endl;
}
