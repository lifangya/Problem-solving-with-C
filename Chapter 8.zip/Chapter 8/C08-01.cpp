#include<iostream>
#include<cstring>
using namespace std;
void find_name(char str[],int size,int& i);
void find_age(char str[],int size,int& i);
void find_title(char str[],int size,int& i);
int main()
{
	int i=0;
	cout<<"Please enter your name, age and title, using a space to seperate each part"<<endl;
	char str[30];
	cin.getline(str,30);
	cout<<"Your name is ";
	find_name(str,strlen(str),i);
	cout<<endl;
	cout<<"Your age is ";
	find_age(str,strlen(str),i);
	cout<<endl;
	cout<<"Your title is ";
	find_title(str,strlen(str),i);
	cout<<endl;
}

void find_name(char str[],int size,int& i)
{
	while(str[i]!=' '&&i<size)
	{
		cout<<str[i];
		i++;
	}
	i++;
	
}

void find_age(char str[],int size,int& i)
{
	while(str[i]!=' '&&i<size)
	{
		cout<<str[i];
		i++;
	}
	i++;
}

void find_title(char str[],int size,int& i)
{
	while(str[i]!='\0'&&i<size)
	{
		cout<<str[i];
		i++;
	}
}
