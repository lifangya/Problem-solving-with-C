#include<iostream>
#include<string>
using namespace std;
int main()
{
	string str;
	cout<<"Please enter your name, age and title, using a space to seperate each part"<<endl;
	getline(cin,str);
	int first_space=str.find(' ');
	string name,age,title;
	name=str.substr(0,first_space);
	cout<<"Your name is "<<name<<endl;
	int second_space=str.find(' ',first_space+1);
	age=str.substr(first_space+1,second_space-first_space);
	cout<<"Your age is "<<age<<endl;
	title=str.substr(second_space+1,str.length());
	cout<<"Your title is "<<title<<endl;
	
}
