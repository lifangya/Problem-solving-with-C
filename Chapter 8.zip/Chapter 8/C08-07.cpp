#include<iostream>
#include<string>
#include<cctype>
using namespace std;
void piglatin(string& s);
void makelower(string& s);
int main()
{
	string first,last,name;
	cout<<"Please enter your first name: ";
	getline(cin,first);
	cout<<"Please enter your last name: ";
	getline(cin,last);
	makelower(first);
	makelower(last);
	piglatin(first);
	piglatin(last);
	name=first+" "+last;
	cout<<"Your pigLatin name is "<<name<<endl;
	
	
}

void makelower(string& s)
{
	for(int i=0;i<s.length();i++)
	s[i]=tolower(s[i]);
}

void piglatin(string& s)
{
	string consonant("aeiou");
	int index=consonant.find(s[0]);
	if(index<0||index>4)
	{
		s=s.substr(1,s.length()-1)+s[0]+"ay";
	}
	else
	{
		s=s+"way";
	}
	s[0]=toupper(s[0]);
}
