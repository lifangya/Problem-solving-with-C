#include<iostream>
#include<vector>
using namespace std;
void swapFrontBack(vector<int>& v);
int main()
{
	vector<int> v;
	int next;
	cout<<"Please enter a vector of integers. Use a letter as end."<<endl;
	while(cin>>next)
	{
		v.push_back(next);
	}
	swapFrontBack(v);
	cout<<"After swap, the vector is now ";
	for(int i=0;i<v.size();i++)
	cout<<v[i]<<" ";
}

void swapFrontBack(vector<int>& v)
{
	int temp;
	temp=v[0];
	v[0]=v[v.size()-1];
	v[v.size()-1]=temp;
	
}
