#include<iostream>
#include<vector>
using namespace std;
void firstlast2(vector<int> v);
int main()
{
	vector<int> v;
	int next;
	cout<<"Please enter a vector of integers. Use a letter as end."<<endl;
	while(cin>>next)
	{
		v.push_back(next);
	}
	firstlast2(v);

}
void firstlast2(vector<int> v)
{
	if(v[0]==2||v[v.size()-1]==2)
	cout<<"true"<<endl;
	else
	cout<<"false"<<endl;
}
