#include<iostream>
#include<string>
using namespace std;
int main()
{
	char ans;
	string first;
	string last;
	string name;
	do
	{
		cout<<"Please enter your first name and last name, using a space as seperation."<<endl;
		getline(cin,name);
		first=name.substr(0,1);
		int space;
		space=name.find(' ');
		last=name.substr(space+1,1);
		cout<<first<<last<<endl;
		cout<<"Try again(y/n)."<<endl;
		cin>>ans;
		cin.ignore();
	}
	while(ans=='y'||ans=='Y');		
}
