//This program gauges the inflation rate for the past year
//using the difference between the price this year and the price of the same
//item one year ago divided by the year-ago price.
//created by LFY on 23//11/2016
#include<iostream>
using namespace std;
double inflation(double year_ago_price,double this_year_price);
//This function reads in the price 1 year ago and this year.
//It return the inflation rate as a percent.
int main()
{   
    double year_ago_price, this_year_price, inflation_rate;
    int done;
    do
    {
	    cout<<"Please enter the price of an item one year ago: $";
	    cin>>year_ago_price;
	    cout<<"Please enter the price of the same item this year: $";
	    cin>>this_year_price;
	    inflation_rate=inflation(year_ago_price,this_year_price);
	    cout.setf(ios::fixed);
	    cout.setf(ios::showpoint);
	    cout.precision(2);
	    cout<<"The inflaton rate for the past year is "<<inflation_rate
	        <<"%."<<endl;
	    cout<<"Enter 0 to exit, 1 to compute again."<<endl;
	    cin>>done;
    }
    while(done!=0);
}
double inflation(double year_ago_price,double this_year_price)
{
	double inflation_rate;
	inflation_rate=(this_year_price-year_ago_price)/year_ago_price*100;
	return inflation_rate;
}

