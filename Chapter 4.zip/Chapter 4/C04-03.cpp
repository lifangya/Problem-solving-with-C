//This program computes the value of the users' holding of one stock.
//Created by LFY on 23/11/2016
#include<iostream>
using namespace std;
double price(int whole,int numerator,int denominator);
//This function computes the total price of the stock the user own��
//It reads in the whole portion of the price, then the numerator 
//of the fraction and then the denominator.
//It returns the total price.
int main()
{
	int whole,numerator,denominator,done;
    double share,total_price,price1share;
    do
	{   
		cout<<"How many shares of stock do you own?" <<endl;
		cin>>share;
		cout<<"Please input the whole-dollar portion, the numerator"
		    <<" of the fraciton portion and the denominator of the price."
			<<endl;
		cin>>whole>>numerator>>denominator;
		total_price=price(whole,numerator,denominator);
		//cout<<total_price<<endl;
		price1share=total_price/share;
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(5);
		cout<<"Your stock is $"<<price1share<<"per share."<<endl;
		cout<<"Enter 0 to exit, 1 to compute again."<<endl;
		cin>>done;	
	}
	while(done!=0);
}

double price(int whole,int numerator,int denominator)
{
	double total_price;
	total_price=whole+static_cast<double>(numerator)/denominator;
	return total_price;
}
