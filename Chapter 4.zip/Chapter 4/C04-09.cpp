#include<iostream>
using namespace std;
double max(double x1,double x2);
double max(double x1,double x2,double x3);
int main()
{
	double x1,x2,x3,x4,x5,big;
	cout<<"Please input three numbers."<<endl;
	cin>>x1>>x2>>x3;
	big=max(x1,x2,x3);
	cout<<"The biggest one is "<<big<<endl; 
	cout<<"Please input two numbers."<<endl;
	cin>>x4>>x5;
	big=max(x4,x5);
	cout<<"The bigger one is "<<big<<endl;
}
double max(double x1,double x2)
{
	return x1>=x2?x1:x2;
}
double max(double x1,double x2,double x3)
{
	if(x1>=x2)
	x2=x1;
	if(x2>=x3)
	x3=x2;
	return x3;
}
