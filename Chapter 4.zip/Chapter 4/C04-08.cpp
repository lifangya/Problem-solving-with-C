#include <iostream>
int    abs(int);
double abs(double);
long   abs(long);
float  abs(float);
int abs(int a)
{
	if (a >= 0)
		return a;
	else 
		return -a;
}

double abs(double a)
{
	if (a >= 0)
		return a;
	else 
		return -a;
}

long abs(long a)
{
	if (a >= 0)
		return a;
	else 
		return -a;
}

float abs(float a)
{
	if (a >= 0)
		return a;
	else 
		return -a;
}
