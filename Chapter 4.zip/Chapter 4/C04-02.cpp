//This program reads in he number of liters of gasoline consumed by 
//the user's car and the number of miles traveld.
//It outputs the number of miles per gallon the car delivered.
//It allows the user to repeat the calculation as he/she wishes.
//Created by LFY on 23/11/2016


#include<iostream>
double Mpg(double gas,double mile);
//This function reads in the number of liters of gasoline consumed by 
//the user's car and the number of miles traveld.
//It returns the number of miles per gallon the car delivered.
using namespace std;
const double lit2gal=0.264179;
int main()
{   
    double gas1,mile1,mpg1,gas2,mile2,mpg2;
    int done;
    do
    {
	    cout<<"Please input the the number of liters"
	        <<" of gasoline the first car consumed,\n"
	        <<"and the miles it traveled."<<endl;
	    cin>>gas1>>mile1;	    
	    cout<<"Please input the the number of liters"
	        <<" of gasoline the second car consumed,\n"
	        <<"and the miles it traveled."<<endl;
	    cin>>gas2>>mile2;	    
	    mpg1=Mpg(gas1,mile1);
	    mpg2=Mpg(gas2,mile2);
	    cout.setf(ios::fixed);
	    cout.setf(ios::showpoint);
	    cout.precision(2);
	    cout<<"The first car delivered "<<mpg1<<" miles oer gallon."<<endl;
	    cout<<"The second car delivered "<<mpg2<<" miles oer gallon."<<endl;
	    if(mpg1>mpg2) 
	       cout<<"The first car has the better fuel-efficiency."<<endl;
	    else if(mpg1<mpg2)
	       cout<<"The second car has the better fuel-efficiency."<<endl;
	    else
	       cout<<"The two cars have exactly the same fuel-efficiency."<<endl; 
	    cout<<"0 to stop, 1 to compute again."<<endl;
	    cin>>done;
	}
	while(done!=0);
} 

double Mpg(double gas,double mile)
{
	double mpg;
	mpg=mile/(gas*lit2gal);
	return mpg;
}

