//This program gauges the inflation rate for the past year
//using the difference between the price this year and the price of the same
//item one year ago divided by the year-ago price.
//This program also estimates the price ot the intem one year later.
//created by LFY on 23//11/2016
#include<iostream>
using namespace std;
double inflation(double year_ago_price,double this_year_price);
//This function reads in the price 1 year ago and this year.
//It return the inflation rate as a percent.
double future_price(double inflation_rate,double this_year_price);
//This function reads in the inflation rate and the price today 
//and return the price in one year.
int main()
{   
    double year_ago_price, this_year_price, inflation_rate,price1y_later;
    int done;
    do
    {
	    cout<<"Please enter the price of an item one year ago: $";
	    cin>>year_ago_price;
	    cout<<"Please enter the price of the same item this year: $";
	    cin>>this_year_price;
	    inflation_rate=inflation(year_ago_price,this_year_price);
	    price1y_later=future_price(inflation_rate,this_year_price);
	    cout.setf(ios::fixed);
	    cout.setf(ios::showpoint);
	    cout.precision(2);
	    cout<<"The inflaton rate for the past year is "<<inflation_rate
	        <<"%."<<endl;
	    cout<<"This estimated price for the item 1 year later is $"
	        <<price1y_later<<endl;
	    cout<<"Enter 0 to exit, 1 to compute again."<<endl;
	    cin>>done;
    }
    while(done!=0);
}
double inflation(double year_ago_price,double this_year_price)
{
	double inflation_rate;
	inflation_rate=(this_year_price-year_ago_price)/year_ago_price*100;
	return inflation_rate;
}
double future_price(double inflation_rate,double this_year_price)
{
	double price1y_later;	
	price1y_later=this_year_price*(1+inflation_rate/100.0);
	return price1y_later; 
}

