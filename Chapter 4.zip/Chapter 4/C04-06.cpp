//This program computes the interest due in one's credit account.
//Created by Lfy on 23/11/2016
#include<iostream>
using namespace std;
double interest(double balance,double rate,int month);
//THis function reads in the account balance, the interest rate and the month due
//It returns the interest due using compunded method.
int main()
{   
    double balance,rate,interest_due;
    int month,done;
	do 
	{
		cout<<"Please enter your account balance,"
	    <<"monthly interest rate and months due."<<endl;
	    cin>>balance>>rate>>month;
		interest_due=interest(balance,rate,month);
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(2);
		cout<<"Your interest due in "<<month<<" months is "<<interest_due<<endl;
		cout<<"Enter 0 to exit,1 to compute again."<<endl;
		cin>>done;
    } 
    while(done!=0);	
	return 0;
	
}
double interest(double balance,double rate,int month)
{
	int i=1;
	double b0;
	b0=balance;
	double interest_due;
	while(i<=month)
	{
		balance=(balance*(1+rate));	
		i++;	
	}
	interest_due=balance-b0;
	return interest_due;
} 
