//This program computes the gravitational force between two objects.
//created by Lfy on 23/11/2016
#include<iostream>
using namespace std;
double gforce(double m1,double m2,double distance);
//This function reads in the masses of two objects and their distance.
//It returns the gravitational force between them
const double G=6.673e-8;
int main()
{
	double m1,m2,distance,force;
	cout<<"Please input the masses of two objects and the distance between them."
	    <<endl;
	while(cin>>m1>>m2>>distance)
	{
		force=gforce(m1,m2,distance);
		cout<<"The gravitational force between them is "<<force<<" dynes."<<endl;	
	}
	return 0;
}
double gforce(double m1,double m2,double distance)
{
	double force;
	force=G*m1*m2/distance/distance;
	return force;
}
