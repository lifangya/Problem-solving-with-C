#include<iostream>
#include<string>
using namespace std;
bool palindrome(string x,int start,int last);
int main()
{
	string x;
	cout<<"Please enter your string.\n";
	getline(cin,x);
	if(palindrome(x,0,x.length()-1))
		cout<<"It is a palindrome.\n";
	else
		cout<<"It isn't a palindrome.\n";
}
bool palindrome(string x,int start,int last)
{
	if((start==last-1&&x[start]==x[last])||start==last)
	{
		return true;
	}
	else if(x[start]!=x[last])
		return false;
	else
	{
		return palindrome(x,start+1,last-1);
	}
		
}
