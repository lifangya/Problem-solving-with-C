#include<iostream>
using namespace std;
int handshake(int n);
int main()
{
	int n,shakes;
	cout<<"How many people are there in the room?"<<endl;
	cin>>n;
	shakes=handshake(n);
	cout<<"They are gonna have "<<shakes<<" handshakes.";
	
}
int handshake(int n)
{
	if(n<1)
	{
		cout<<"Invalid number of people."<<endl;
		exit(1);
	}
	else if(n==1)
		return 0;
	else if(n==2)
		return 1;
	else
	{
		return(handshake(n-1)+n-1);
	}
}
