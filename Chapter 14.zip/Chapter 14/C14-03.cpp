#include<iostream>
using namespace std;
int search(const int a[], int start, int number_used, int target);
int main()
{
	int a[10]={3,44,54,23,101,77,689,1,19,8};
	cout<<search(a,0,10,101);
}
int search(const int a[], int start, int number_used, int target)
{
	if(start>=number_used)
	{
		cout<<"number not found.";
		exit(1);
	}
	else if (target==a[start])
		return start;
	else
	{
		return search(a,start+1,number_used,target);
	}
}
