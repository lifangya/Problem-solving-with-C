#include<iostream>
int index_of_smallest(const int a[],int start_index,int number_used);
bool smaller(int x,int y);
using namespace std;
int main()
{
	int a[10]={89,33,21,35,67,11,38,22,100,24};
	cout<<index_of_smallest(a,2,10);
	
}
bool smaller(int x,int y)
{
	if(x<=y)
		return true;
	else
		return false;
}
int index_of_smallest(const int a[],int start_index,int number_used)
{
	if(start_index>=number_used)
	{
		cout<<"Illegal start index.";
		exit(1);
	}
	else if(start_index==number_used-1)
		return(number_used-1);
	else
		{
			int temp;
			temp=index_of_smallest(a,start_index+1,number_used);
			if(smaller(a[start_index],a[temp]))
				return start_index;
			else
				return temp;
		}
		
}
