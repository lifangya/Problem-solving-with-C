//Chapter3 PP 1
//This program plays the paper scissors rock game
//created by LFY in 20-11-2016
#include<iostream>
using namespace std;
int main()
{
	char user1,user2,done;
  do
  {
	cout<<"please choose your paper, sicissors"
	    <<"and rock using P S R respectively."<<endl; 
	cin>>user1>>user2;
	if(user1=='R'||user1=='r')
	  {
		if(user2=='S'||user2=='s')
	    cout<<"Rock breaks scissors and User1 wins."<<endl;
	    else if(user2=='P'||user2=='p')
	    cout<<"Paper covers rock and User2 wins."<<endl;
	    else
	    cout<<"No one wins."<<endl;
	  }
	else if(user1=='P'||user1=='p')
	   {
	   	if(user2=='S'||user2=='s')
	    cout<<"Sicissors cut paper and User2 wins."<<endl;
	    else if(user2=='R'||user2=='r')
	    cout<<"Paper covers rock and User1 wins."<<endl;
	    else
	    cout<<"No one wins."<<endl;
	   }
	else
	   {
	    if(user2=='R'||user2=='r')
	    cout<<"Rock breaks scissors and User2 wins."<<endl;
	    else if(user2=='P'||user2=='p')
	    cout<<"Siccors cut paper and User1 wins."<<endl;
	    else
	    cout<<"No one wins."<<endl;
	   }
	cout<<"Enter N if you want to stop, enter Y to play again."<<endl;
	cin>>done;
  } 
	while(done!='N'&&done!='n');
}
