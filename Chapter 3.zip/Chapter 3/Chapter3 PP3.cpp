//Chapter 3 PP 3
//This program tells the user his/her horoscope sign for his/her birthday
//created by LFY on 20-11-2016

#include<iostream>
using namespace std;
int main()
{   int month, day;
	cout<<"Please tell me your birthday month."<<endl;
	cin>>month;
	cout<<"Please tell me on which day you were born in "<<month<<endl;
	cin>>day;
	if((month==3&&day<=31&&day>=23)||(month==4&&day>=1&&day<=17))
	cout<<"You are Aries"<<endl;
	else if(month==3&&day==21||day==22)
	cout<<"You are Aries and you are on the cusp of Aries and Pisces."<<endl;
	else if(month==4&&day==18||day==19)
	cout<<"You are Aries and you are on the cusp of Aries and Taurus."<<endl;
}
