//Chapter3 PP 2
//This program computes the interest due, total amount due, and the
//minimum payment for a revolving credit account.
//Created by LFY on 20-11-2016


#include<iostream>
using namespace std;
int main()
{
	double balance,total,pay,interest;
	char done;
  do
  {
	cout<<"please enter your account balance: $";
	cin>>balance;
// The interest is 1.5 percent on the first
 // $1,000 and 1 percent on any amount over that.	
	  if(balance<=1000)
	    {
	      interest=0.015*balance;
	      total=interest+balance;
		 }                           
	  else 
	    {
		  interest=0.015*1000+0.01*(balance-1000);
	     total=interest+balance;
	    }
//The minimum payment
//is the total amount due if that is $10 or less; otherwise, it is $10 or
//10 percent of the total amount owed, whichever is larger
	  if(total<=10)
	     pay=total;
	   else
	     pay=0.1*total>=10?(0.1*total):10;
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
	cout<<"The interest due on your account is $"<<interest
	    <<"\nThe total amout due is $"<<total
	    <<"\nThe minimum payment is $"<<pay<<endl;
	cout<<"Do you want to try again? N for no and Y for yes."<<endl;
	cin>>done;  
 }
   while(done!='N'&&done!='n');
	
}
