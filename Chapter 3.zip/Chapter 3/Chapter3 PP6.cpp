//Chapter3 PP6
//This program compute the boyant force
//Created by Lfy on 20-11-2016

#include<iostream>
using namespace std;
int main()
{
	double w,r,force;
	const double Gamma=62.4;
	const double PI=3.14159265;
	cout<<"Please input the weight and radius of the sphere."<<endl;
	cin>>w>>r;
	force=4.0/3*PI*r*r*r*Gamma;
	if(force>=w)
	cout<<"The sphere will float in water.";
	else
	cout<<"The sphere will sink in water.";
	
}
