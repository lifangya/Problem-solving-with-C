#include <iostream>
using namespace std;
int main()
{

	int C = 100;
	double F =280;
	while (C != F)
	{
		C--;
		F = (9 * C) / 5.0 + 100;
	}
	cout << C << " " << F << endl;
}
