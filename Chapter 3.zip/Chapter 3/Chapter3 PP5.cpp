//Chapter 3 PP 5
//This programs output prime numbers between 3 and 100
//Created by Lfy on 20-11-2016

#include<iostream>
using namespace std;
int main()
{
	int i,j,s;
	for(i=3;i<=100;i++)
	{
		s=0;
	    for(j=2;j<=i-1;j++)
	    {	
	    	if(i%j==0)
	    	s++;	
	    }
	if(s==0)
	cout<<i<<" ";	    
   }
} 
